var searchData=
[
  ['proc_5ffs_5fmsg_5fmax',['PROC_FS_MSG_MAX',['../task_queue_8c.html#aa188cdbc02660db180e15737f7abc881',1,'taskQueue.c']]],
  ['proc_5ffs_5fmsgsize_5fmax',['PROC_FS_MSGSIZE_MAX',['../task_queue_8c.html#af0556690ba1a7565af3ab9ea201a79cd',1,'taskQueue.c']]]
];
