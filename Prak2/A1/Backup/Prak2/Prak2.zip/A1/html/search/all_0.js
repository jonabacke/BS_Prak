var searchData=
[
  ['argsize',['argSize',['../struct_task_header.html#a012676466db59ff95197feedff7f58ea',1,'TaskHeader']]]
];
