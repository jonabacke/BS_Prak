var searchData=
[
  ['closetaskqueue',['closeTaskQueue',['../task_queue_8h.html#a42025c891f1f2929df9c52c9b7f4efa0',1,'closeTaskQueue(const mqd_t mqdes):&#160;taskQueue.c'],['../task_queue_8c.html#a42025c891f1f2929df9c52c9b7f4efa0',1,'closeTaskQueue(const mqd_t mqdes):&#160;taskQueue.c']]],
  ['createtaskqueue',['createTaskQueue',['../task_queue_8h.html#af4900cc3c9aee6b8d95588ef69544bbe',1,'createTaskQueue(const char *name, const unsigned int queueSize, const unsigned int maxArgSize):&#160;taskQueue.c'],['../task_queue_8c.html#af4900cc3c9aee6b8d95588ef69544bbe',1,'createTaskQueue(const char *name, const unsigned int queueSize, const unsigned int maxArgSize):&#160;taskQueue.c']]]
];
