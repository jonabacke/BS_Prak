var searchData=
[
  ['readintfromfile',['readIntFromFile',['../task_queue_8c.html#a489ca295f17ab7fefc6a42f658e7b197',1,'taskQueue.c']]],
  ['receivefromtaskqueue',['receiveFromTaskQueue',['../task_queue_8h.html#ab6b5d215d3c4baf0615c5fb58aff7680',1,'receiveFromTaskQueue(const mqd_t mqdes, struct TaskHeader *t, char *argBuf, const unsigned int sizeOfArgBuf):&#160;taskQueue.c'],['../task_queue_8c.html#ab6b5d215d3c4baf0615c5fb58aff7680',1,'receiveFromTaskQueue(const mqd_t mqdes, struct TaskHeader *t, char *argBuf, const unsigned int sizeOfArgBuf):&#160;taskQueue.c']]]
];
