var searchData=
[
  ['taskheader',['TaskHeader',['../struct_task_header.html',1,'']]]
];
