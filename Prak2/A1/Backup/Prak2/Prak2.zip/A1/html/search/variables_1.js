var searchData=
[
  ['routinefortask',['routineForTask',['../struct_task_header.html#adbc147212dd13ff3f6501a62738002bb',1,'TaskHeader']]]
];
