var searchData=
[
  ['default_5fpriority',['DEFAULT_PRIORITY',['../task_queue_8c.html#a0756f011ef667460d583017366823244',1,'taskQueue.c']]],
  ['destroytaskqueue',['destroyTaskQueue',['../task_queue_8h.html#ab45dc7a4151a5cfae381c0f5eb502b98',1,'destroyTaskQueue(const char *name):&#160;taskQueue.c'],['../task_queue_8c.html#ab45dc7a4151a5cfae381c0f5eb502b98',1,'destroyTaskQueue(const char *name):&#160;taskQueue.c']]]
];
