var searchData=
[
  ['sendtotaskqueue',['sendToTaskQueue',['../task_queue_8h.html#a01fd56835edf9980c60c289cc59037d8',1,'sendToTaskQueue(const mqd_t mqdes, const struct TaskHeader t, const char *arg, const bool blocking):&#160;taskQueue.c'],['../task_queue_8c.html#a01fd56835edf9980c60c289cc59037d8',1,'sendToTaskQueue(const mqd_t mqdes, const struct TaskHeader t, const char *arg, const bool blocking):&#160;taskQueue.c']]]
];
