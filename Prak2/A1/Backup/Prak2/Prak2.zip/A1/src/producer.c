#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/sem.h>
#include <semaphore.h>
#include <malloc.h>
#include <errno.h>

#include "producer.h"



void *producerOne(void *stack)
{
    char alphabet[] = "abcdefghijklmnopqrstuvwxyz";
    while (1)
    {
        for (int i = 0; i < sizeof(alphabet); i++)
        {
            producer(stack, alphabet[i], producerThreadOne);
            printf("P1 schreibt %c in Puffer \n", alphabet[i]);
    printf("HI1\n");
            sleep(3);
        }
    }
}

void *producerTwo(void *stack)
{
    char alphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    while (1)
    {
        for (int i = 0; i < sizeof(alphabet); i++)
        {
            producer(stack, alphabet[i], producerThreadTwo);
            printf("P2 schreibt %c in Puffer \n", alphabet[i]);
            sleep(3);
        }
    }
}


void producer(FIFOStack *stack, char value, CPThread *thread)
{
    void cancelDisable();
    mutex_lock(thread->pause);
#ifdef condition
    mutex_lock(stack->fifo);
    while (stack_full(stack))
    {
        cond_wait(stack->nonFull, stack->fifo);
    }
    stack->array[stack->next_in] = value;
    stack->next_in = stack_incr(stack, stack->next_in);
    mutex_unlock(stack->fifo);
    cond_signal(stack->nonFull);
#else
    semaphore_wait(stack->spaces);
    mutex_lock(stack->fifo);
    stack->array[stack->next_in] = value;
    stack->next_in = stack_incr(stack, stack->next_in);
    mutex_unlock(stack->fifo);
    semaphore_post(stack->items);
#endif // cond
    mutex_unlock(thread->pause);
    cancelEnable();
}