

#include <stdio.h>
#include <stddef.h>



#include "taskQueue.h"
#include "getcharTimeout.c"
#include "producer.h"
#include "general.h"

void initProducerQueue();