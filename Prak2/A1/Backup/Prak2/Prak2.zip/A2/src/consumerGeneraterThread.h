

#include <stdio.h>
#include <stddef.h>



#include "taskQueue.h"
#include "getcharTimeout.c"
#include "consumer.h"
#include "general.h"

void initConsumerQueue();